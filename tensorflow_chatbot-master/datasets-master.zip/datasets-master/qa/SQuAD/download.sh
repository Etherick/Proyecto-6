wget -c 'https://rajpurkar.github.io/SQuAD-explorer/dataset/train-v1.1.json'
wget -c 'https://rajpurkar.github.io/SQuAD-explorer/dataset/dev-v1.1.json'
